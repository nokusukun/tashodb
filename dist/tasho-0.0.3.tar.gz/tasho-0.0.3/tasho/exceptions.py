
class DatabaseInitException(Exception):
	pass

class DatabaseOperationException(Exception):
	pass

class TableSeclectorException(Exception):
	pass