class AutoGenerateId():
    pass